import argparse

parser = argparse.ArgumentParser(description='A plus B')
parser.add_argument('data', type=argparse.FileType('r'))
parser.add_argument('-t', metavar='time', type=int, required=True)
parser.add_argument('-c', metavar='cpu', type=int, required=True)
parser.add_argument('-m', metavar='memory', type=int, required=True)
args = parser.parse_args()
data = args.data

line = data.readlines()[0]
splitted = line.split(' ')

a = int(splitted[0])
b = int(splitted[1])

print(a + b)
