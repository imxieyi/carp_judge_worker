boom = bytearray(512000000)
