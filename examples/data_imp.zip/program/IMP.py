print('56\n58\n53\n51\n48')
