import string
import random

def garbage_generator(size=1000, chars=string.ascii_uppercase + string.digits):
    return ''.join(random.choice(chars) for _ in range(size))

while True:
	print(garbage_generator())
